-- ============================================================
-- DCL MINING — COMPLETE SUPABASE SETUP (FULL RESET)
-- Paste ALL of this into: Supabase → SQL Editor → Run
-- This drops old tables and rebuilds everything cleanly
-- ============================================================

-- ── STEP 1: DROP EVERYTHING (clean reset) ─────────────────
drop table if exists public.boost_txs   cascade;
drop table if exists public.withdrawals cascade;
drop table if exists public.profiles    cascade;
drop function if exists public.handle_updated_at cascade;
drop function if exists public.add_referral_bonus cascade;

-- ── STEP 2: PROFILES TABLE ────────────────────────────────
create table public.profiles (
  id              bigserial primary key,
  telegram_id     text unique not null,
  username        text,
  balance         numeric(20,8) not null default 0,
  taps            bigint not null default 0,
  streak          int not null default 0,
  last_checkin    date,
  per_tap         numeric(10,6) not null default 0.005,
  boost_name      text not null default 'x5',
  upgrades        jsonb not null default '{"multitap":1,"energy":0,"recharge":1,"bot":0}'::jsonb,
  tasks           jsonb not null default '{}'::jsonb,
  achievements    jsonb not null default '{}'::jsonb,
  referred_by     text,
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now()
);

create index profiles_balance_idx     on public.profiles(balance desc);
create index profiles_taps_idx        on public.profiles(taps desc);
create index profiles_referred_by_idx on public.profiles(referred_by);
create index profiles_username_idx    on public.profiles(username);

-- ── STEP 3: WITHDRAWALS TABLE ─────────────────────────────
create table public.withdrawals (
  id              bigserial primary key,
  telegram_id     text not null,
  username        text,
  wallet_addr     text not null,
  amount          numeric(20,8) not null,
  status          text not null default 'pending'
                    check (status in ('pending','approved','rejected')),
  admin_note      text,
  tx_hash_out     text,
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now()
);

create index withdrawals_telegram_id_idx on public.withdrawals(telegram_id);
create index withdrawals_status_idx      on public.withdrawals(status);
create index withdrawals_created_at_idx  on public.withdrawals(created_at desc);

-- ── STEP 4: BOOST TRANSACTIONS TABLE ──────────────────────
create table public.boost_txs (
  id              bigserial primary key,
  telegram_id     text not null,
  username        text,
  tx_hash         text unique not null,
  boost           text not null,
  amount_bnb      numeric(18,8) not null,
  verified_at     timestamptz not null default now()
);

create index boost_txs_telegram_id_idx on public.boost_txs(telegram_id);
create index boost_txs_verified_at_idx on public.boost_txs(verified_at desc);

-- ── STEP 5: AUTO-UPDATE TRIGGER ───────────────────────────
create function public.handle_updated_at()
returns trigger language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

create trigger profiles_updated_at
  before update on public.profiles
  for each row execute function public.handle_updated_at();

create trigger withdrawals_updated_at
  before update on public.withdrawals
  for each row execute function public.handle_updated_at();

-- ── STEP 6: REFERRAL BONUS FUNCTION ──────────────────────
-- Called when a new user joins via referral link
-- Adds 5 DCL to the referrer's balance
create function public.add_referral_bonus(ref_id text, bonus numeric)
returns void language plpgsql security definer as $$
begin
  update public.profiles
    set balance = balance + bonus,
        updated_at = now()
    where telegram_id = ref_id;
end;
$$;

-- ── STEP 7: ROW LEVEL SECURITY ────────────────────────────
alter table public.profiles    enable row level security;
alter table public.withdrawals enable row level security;
alter table public.boost_txs   enable row level security;

-- Profiles: open read (leaderboard), open insert/update (app uses anon key)
create policy "profiles_select"
  on public.profiles for select using (true);

create policy "profiles_insert"
  on public.profiles for insert with check (true);

create policy "profiles_update"
  on public.profiles for update using (true) with check (true);

-- Withdrawals: open (filtered client-side by telegram_id)
create policy "withdrawals_select"
  on public.withdrawals for select using (true);

create policy "withdrawals_insert"
  on public.withdrawals for insert with check (true);

create policy "withdrawals_update"
  on public.withdrawals for update using (true) with check (true);

-- Boost txs: open read/insert (verified server-side via BSC RPC)
create policy "boosts_select"
  on public.boost_txs for select using (true);

create policy "boosts_insert"
  on public.boost_txs for insert with check (true);

-- ── STEP 8: GRANT FUNCTION EXECUTE ────────────────────────
grant execute on function public.add_referral_bonus(text, numeric) to anon, authenticated;

-- ── STEP 9: REALTIME (live leaderboard) ───────────────────
alter publication supabase_realtime add table public.profiles;

-- ── DONE ─────────────────────────────────────────────────
-- Tables created:
--   public.profiles    — player data, balance, tasks, upgrades
--   public.withdrawals — withdrawal requests (admin approves)
--   public.boost_txs   — BNB boost payments (BSC verified)
--
-- Functions:
--   add_referral_bonus(ref_id, bonus) — credits referrer 5 DCL
--   handle_updated_at()              — auto-updates updated_at
--
-- After running this, your DCL Mining app is fully connected.
-- ─────────────────────────────────────────────────────────

notify pgrst, 'reload schema';
